//
//  BaiduMapViewController.h
//  shequ
//
//  Created by yuxin tang on 14-5-4.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BMapKit.h"

@interface BaiduMapViewController : UIViewController<BMKMapViewDelegate>
@property (strong, nonatomic) IBOutlet BMKMapView *mapView;

@end
