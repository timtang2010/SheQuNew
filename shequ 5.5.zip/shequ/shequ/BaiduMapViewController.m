//
//  BaiduMapViewController.m
//  shequ
//
//  Created by yuxin tang on 14-5-4.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import "BaiduMapViewController.h"

@interface BaiduMapViewController ()
@property (strong, nonatomic) UISegmentedControl * uiscontrol;

@end

@implementation BaiduMapViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSArray *scarray = [[NSArray alloc] initWithObjects:@"显示",@"隐藏",@"定位",nil];
	self.uiscontrol = [[UISegmentedControl alloc] initWithItems:scarray];
    self.uiscontrol.frame = CGRectMake(20, 525, 150, 25);
    self.uiscontrol.tintColor = [UIColor redColor];//设置分段器的颜色
    self.uiscontrol.backgroundColor = [UIColor whiteColor];//背景颜色
    self.uiscontrol.momentary = NO;//点击后是否恢复原样
    [self.uiscontrol addTarget:self
                        action:@selector(select:)
              forControlEvents:UIControlEventValueChanged];
    self.uiscontrol.selectedSegmentIndex = 0;//默认选中
    [self.view addSubview:self.uiscontrol];
    
    self.mapView.delegate = self;
    
    self.mapView.showsUserLocation = YES;
    // 用于测试成功从 Storyboard 加载
    NSLog(@"BaiduMap From Storyborad");
    
    //让分页栏显示在地图上
    [self.view insertSubview:self.uiscontrol aboveSubview:self.mapView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated {
    
    self.mapView.delegate = self; // 此处记得不用的时候需要置nil，否则影响内存的释放
}

-(void)viewWillDisappear:(BOOL)animated
{
    self.mapView.delegate = nil;
}


/**
 *在地图View将要启动定位时，会调用此函数
 *@param mapView 地图View
 */
- (void)mapViewWillStartLocatingUser:(BMKMapView *)mapView
{
	NSLog(@"start locate");
}

/**
 *用户位置更新后，会调用此函数
 *@param mapView 地图View
 *@param userLocation 新的用户位置
 */

- (void)mapView:(BMKMapView *)mapView didUpdateUserLocation:(BMKUserLocation *)userLocation
{
	if (userLocation != nil)
    {
		NSLog(@"%f %f", userLocation.location.coordinate.latitude, userLocation.location.coordinate.longitude);
	}
}


/**
 *在地图View停止定位后，会调用此函数
 *@param mapView 地图View
 */
- (void)mapViewDidStopLocatingUser:(BMKMapView *)mapView
{
    NSLog(@"stop locate");
}

/**
 *定位失败后，会调用此函数
 *@param mapView 地图View
 *@param error 错误号，参考CLError.h中定义的错误号
 */
- (void)mapView:(BMKMapView *)mapView didFailToLocateUserWithError:(NSError *)error
{
	if (error != nil)
    {
		NSLog(@"locate failed: %@", [error localizedDescription]);
    }
	else
    {
		NSLog(@"locate failed");
	}
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
