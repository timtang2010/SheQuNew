//
//  RegisterViewController.h
//  shequ
//
//  Created by WEB08-V5MCS006 on 14-4-22.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField * nameTextField;
@property (strong, nonatomic) IBOutlet UITextField * passwordTextField;
@property (strong, nonatomic) IBOutlet UITextField * surePasswordTextField;
@property (strong, nonatomic) IBOutlet UITextField * phoneTextField;

- (IBAction)textFieldDone:(id)sender;
- (IBAction)clickBackground:(id)sender;
- (IBAction)registerUser:(id)sender;

@end
