//
//  ProjectExpressNewsTableViewController.h
//  shequ
//
//  Created by yuxin tang on 14-4-24.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProjectExpressMovingTableViewController : UITableViewController

@property (strong, nonatomic) IBOutlet UITableView *movingTableView;
@property (strong, nonatomic) NSDictionary * dictData;
@property (strong, nonatomic) NSArray *listData;

@end
