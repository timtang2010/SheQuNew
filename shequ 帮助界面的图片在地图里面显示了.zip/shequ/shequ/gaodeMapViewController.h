//
//  gaodeMapViewController.h
//  shequ
//
//  Created by yuxin tang on 14-4-29.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import "ViewController.h"
#import <MAMapKit/MAMapKit.h>
#import <AMapSearchKit/AMapSearchAPI.h>

@interface gaodeMapViewController : ViewController<MAMapViewDelegate,AMapSearchDelegate>
{
    BOOL canUpdate; //开始更新
}
@property (nonatomic, strong) MAMapView *mapView;
@property (nonatomic,retain) AMapSearchAPI *search;//搜索
@property (nonatomic,assign)double beginlatitude;//纬度开始
@property (nonatomic,assign)double beginlongitude;//经度开始

@end
