//
//  ProjectExpressViewController.h
//  shequ
//
//  Created by yuxin tang on 14-4-22.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProjectExpressScrollerView.h"

@interface ProjectExpressViewController : UIViewController<ValueClickDelegate>
@property (strong, nonatomic) NSArray *urls;

@end
