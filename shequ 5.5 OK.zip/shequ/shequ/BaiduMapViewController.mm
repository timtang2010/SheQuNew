//
//  BaiduMapViewController.m
//  shequ
//
//  Created by yuxin tang on 14-5-4.
//  Copyright (c) 2014年 v5mcs. All rights reserved.
//

#import "BaiduMapViewController.h"

@interface BaiduMapViewController ()
@property (strong, nonatomic) UISegmentedControl * uiscontrol;

@end

@implementation BaiduMapViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSArray *scarray = [[NSArray alloc] initWithObjects:@"显示",@"隐藏",@"定位",nil];
	self.uiscontrol = [[UISegmentedControl alloc] initWithItems:scarray];
    self.uiscontrol.frame = CGRectMake(160, 525, 150, 25);
    self.uiscontrol.tintColor = [UIColor redColor];//设置分段器的颜色
    self.uiscontrol.backgroundColor = [UIColor whiteColor];//背景颜色
    self.uiscontrol.momentary = NO;//点击后是否恢复原样
    [self.uiscontrol addTarget:self
                        action:@selector(select:)
              forControlEvents:UIControlEventValueChanged];
    self.uiscontrol.selectedSegmentIndex = 0;//默认选中
    [self.view addSubview:self.uiscontrol];
    
    self.mapView.delegate = self;
    
    self.mapView.showsUserLocation = YES;
    // 用于测试成功从 Storyboard 加载
    NSLog(@"BaiduMap From Storyborad");
    
    //指南针的
    self.mapView.compassPosition = CGPointMake(240, 300);
    
    
//    //比例尺的
//    _mapView.mapScaleBarPosition = CGPointMake(240,280);
    
    self.mapView.showMapScaleBar = YES;
    
    //让分页栏显示在地图上
    [self.view insertSubview:self.uiscontrol aboveSubview:self.mapView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated {
    [_mapView viewWillAppear];
    self.mapView.delegate = self; // 此处记得不用的时候需要置nil，否则影响内存的释放
}

-(void)viewWillDisappear:(BOOL)animated
{
    [_mapView viewWillDisappear];
    self.mapView.delegate = nil;
}


/**
 *在地图View将要启动定位时，会调用此函数
 *@param mapView 地图View
 */
- (void)mapViewWillStartLocatingUser:(BMKMapView *)mapView
{
	NSLog(@"start locate");
}

/**
 *用户位置更新后，会调用此函数
 *@param mapView 地图View
 *@param userLocation 新的用户位置
 */

- (void)mapView:(BMKMapView *)mapView didUpdateUserLocation:(BMKUserLocation *)userLocation
{
	if (userLocation != nil)
    {
		NSLog(@"%f %f", userLocation.location.coordinate.latitude, userLocation.location.coordinate.longitude);
	}
}


/**
 *在地图View停止定位后，会调用此函数
 *@param mapView 地图View
 */
- (void)mapViewDidStopLocatingUser:(BMKMapView *)mapView
{
    NSLog(@"stop locate");
}

/**
 *定位失败后，会调用此函数
 *@param mapView 地图View
 *@param error 错误号，参考CLError.h中定义的错误号
 */
- (void)mapView:(BMKMapView *)mapView didFailToLocateUserWithError:(NSError *)error
{
	if (error != nil)
    {
		NSLog(@"locate failed: %@", [error localizedDescription]);
    }
	else
    {
		NSLog(@"locate failed");
	}
}

//分页栏的方法
- (void)select:(id)sender {
    UISegmentedControl *control = (UISegmentedControl *)sender;
    switch (control.selectedSegmentIndex) {
        case 0:
            [self setartLocation:control];
            break;
        case 1:
            [self stopLocation:control];
            break;
        case 2:
            [self startFollowing:control];
            break;
            
        default:
            break;
    }
}

//显示
- (void)setartLocation:(UISegmentedControl *)sender
{
    NSLog(@"进入普通定位状态");
    self.mapView.showsUserLocation = NO;//先关闭显示定位图层
    self.mapView.userTrackingMode = BMKUserTrackingModeNone;//设定定位的状态
    self.mapView.showsUserLocation = YES;//显示定位图层
}

//隐藏
- (void)stopLocation:(UISegmentedControl *)sender
{
    self.mapView.userTrackingMode = BMKUserTrackingModeNone;
    self.mapView.showsUserLocation = NO;
}

//跟随
- (void)startFollowing:(UISegmentedControl *)sender
{
    NSLog(@"进入跟随状态");
    self.mapView.showsUserLocation = NO;
    self.mapView.userTrackingMode = BMKUserTrackingModeFollow;
    self.mapView.showsUserLocation = YES;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
